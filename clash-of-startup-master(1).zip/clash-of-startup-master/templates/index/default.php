<?php
	$incs = new internalIncs();
	$incs->head('Accueil');
?>
<?php 
	$incs->header('accueil');
	$incs->carousel();
?>
<?php
	$incs->footer();

	<footer>
		<div class="container">

		<div class="row">
			<div>
				<a class="footer-brand" href="<?php echo HTTP_PWD; ?>">Clash Of Startup</a>
				<p>Avec Clash Of Startup, votez pour les meilleurs startup et participez activement à l'avenir de votre école !</p>
			</div>
			<div>
			<h3>CONTACT</h3>
			<address>
				Email : <a class="white-link" href="mailto:clashofstartup@gmail.com" title="Nous envoyer un mail">clashofstartup@gmail.com</a><br/>
			</address>
			</div>
			
		</div><!-- /.row -->

		</div><!-- /.container -->
	</footer>

	<div class="footer-after">
		<div class="container">
			<div class="row">
				<p class="col-md-12">©2015 Clash Of Startup.</p>
			</div> <!-- /.row -->
		</div>
	</div>
	</body>
</html>

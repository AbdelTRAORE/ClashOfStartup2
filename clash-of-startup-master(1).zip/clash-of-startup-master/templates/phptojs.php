	HTTP_PWD = "<?php echo HTTP_PWD; ?>"
	csrfToken = "<?php echo $_SESSION['csrf']; ?>"
